from django.apps import AppConfig


class RetakeAppConfig(AppConfig):
    name = 'Retake_app'
